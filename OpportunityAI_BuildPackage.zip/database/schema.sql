
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255),
    role VARCHAR(50),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE translations (
    id SERIAL PRIMARY KEY,
    military_term VARCHAR(255),
    civilian_translation TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE recruiter_locations (
    id SERIAL PRIMARY KEY,
    branch VARCHAR(50),
    address VARCHAR(255),
    city VARCHAR(100),
    state VARCHAR(50),
    zip_code VARCHAR(20),
    latitude FLOAT,
    longitude FLOAT,
    phone VARCHAR(50),
    email VARCHAR(255)
);
